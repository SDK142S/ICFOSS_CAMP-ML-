import streamlit as st
from joblib import load
from PIL import Image
import cv2
from sklearn.preprocessing import scale
import numpy as np

model = load("SVC_MNIST.joblib")


st.title("Handwritten Digit Recognition Using SVM")
image = st.file_uploader(
    "Choose an Handwritten Digit Image", type=["jpeg", "png", "jpg"]
)


def predict(image):
    image = cv2.resize(image, (28, 28))
    image = scale(1 - image / 255).reshape(
        784,
    )
    return model.predict([image])[0]


if st.button("Predict"):
    col1, col2 = st.columns(2)
    with col1:
        st.image(image.read())
    with col2:
        image = Image.open(image).convert("L")
        st.subheader(f"Predicted Digit: {predict(np.array(image))}")
