import streamlit as st

st.title("Shahin")
text = st.text_input("Enter Your Name")
st.subheader(text)
# st.image("8.jpg")
